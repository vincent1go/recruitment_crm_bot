BOT_TOKEN = "7511704960:AAH-rIBOQkhzYvTVOp2tiodxzK3vp8GUiYM"
ADMIN_ID = "6587507343"
WEBHOOK_URL = "https://telegram-pdf-bot-1f5c.onrender.com/telegram"

# Путь к шаблонам PDF
TEMPLATES = {
    "UR Recruitment LTD": "clean_template_no_text.pdf",
    "SMALL WORLD RECRUITMENT LTD": "template_small_world.pdf",
    "IMPERATIVE PEOPLE LIMITED": "template_imperative.pdf"
}
